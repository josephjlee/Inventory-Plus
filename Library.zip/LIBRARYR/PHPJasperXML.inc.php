<?php

global $phpjasperversion;

if($phpjasperversion=="")
	$phpjasperversion='1.0';

include "PHPJasperXML-".$phpjasperversion.".inc.php";